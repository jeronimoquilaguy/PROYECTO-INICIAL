import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas unitarias del Ciclo 4 de SlotMachine.
 */
public class SlotMachineC4Test {

    /**
     * Comprueba que una rueda Rebel no puede eliminarse.
     */
    @Test
    public void testRebelNoSePuedeEliminar() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel("rebel", 1);

        int cantidadAntes = maquina.configuration().length;
        maquina.delWheel(1);
        int cantidadDespues = maquina.configuration().length;

        assertEquals(cantidadAntes, cantidadDespues);
        assertFalse(maquina.ok());
    }

    /**
     * Comprueba que una rueda Rebel no puede bloquearse.
     */
    @Test
    public void testRebelNoSePuedeBloquear() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel("rebel", 1);

        maquina.lock(1);

        assertFalse(maquina.ok());
    }

    /**
     * Comprueba que una rueda Lefty copia el color
     * de la rueda que esta a su izquierda.
     */
    @Test
    public void testLeftyCopiaLaRuedaIzquierda() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel("normal", 1);
        maquina.addWheel("lefty", 2);

        maquina.placeSymbol(1, "red");
        maquina.placeSymbol(2, "blue");
        maquina.spin(2, 1);

        String[] configuracion = maquina.configuration();

        assertEquals(configuracion[0], configuracion[1]);
    }

    /**
     * Comprueba que un simbolo Ephemeral disminuye
     * su tamaño cuando es seleccionado.
     */
    @Test
    public void testEphemeralDisminuye() {
        SimboloEphemeral simbolo = new SimboloEphemeral("red");

        int tamanoInicial = simbolo.obtenerTamano();
        simbolo.seleccionado();

        assertEquals(tamanoInicial - 1, simbolo.obtenerTamano());
    }

    /**
     * Comprueba que un simbolo Shy cambia
     * su visibilidad cuando es seleccionado.
     */
    @Test
    public void testShyCambiaVisibilidad() {
        SimboloShy simbolo = new SimboloShy("blue");

        boolean visibilidadInicial = simbolo.estaVisible();
        simbolo.seleccionado();

        assertEquals(!visibilidadInicial, simbolo.estaVisible());
    }

    /**
     * Comprueba que una rueda Rebel no puede intercambiarse.
     */
    @Test
    public void testRebelNoSePuedeIntercambiar() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel("rebel", 1);
        maquina.addWheel("normal", 2);
        maquina.placeSymbol(2, "blue");
        maquina.swap(1, 2);
        assertFalse(maquina.ok());
        assertEquals("blue", maquina.configuration()[1]);
    }

    /**
     * Comprueba que una rueda Lefty si se puede bloquear y desbloquear.
     */
    @Test
    public void testLeftySePuedeBloquear() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel("lefty", 1);
        assertEquals(1, maquina.lock(1));
        maquina.unlock(1);
        assertTrue(maquina.ok());
    }

    /**
     * Comprueba que una rueda Lefty en la primera posicion gira normalmente.
     */
    @Test
    public void testLeftySinIzquierdaGiraNormal() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel("lefty", 1);
        maquina.spin(1, 1);
        assertEquals("blue", maquina.configuration()[0]);
    }

    /**
     * Comprueba que un simbolo Ephemeral se hace mas pequeño al girar la rueda.
     */
    @Test
    public void testEphemeralEnLaMaquina() {
        SlotMachine maquina = new SlotMachine();
        maquina.addSymbol("ephemeral", 1, "yellow");
        maquina.addWheel(1);
        maquina.placeSymbol(1, "yellow");
        int antes = maquina.tamanoSimbolo(1);
        maquina.spin(1, 4);
        assertEquals("yellow", maquina.configuration()[0]);
        assertEquals(antes - 1, maquina.tamanoSimbolo(1));
    }

    /**
     * Comprueba que un simbolo Shy se oculta al ser seleccionado en la rueda.
     */
    @Test
    public void testShyEnLaMaquina() {
        SlotMachine maquina = new SlotMachine();
        maquina.addSymbol("shy", 2, "cyan");
        maquina.addWheel(1);
        maquina.spin(1, 1);
        assertEquals("cyan", maquina.configuration()[0]);
        assertFalse(maquina.simboloVisible(1));
    }

    /**
     * Comprueba que un simbolo Lucky crece cuando tiene suerte.
     */
    @Test
    public void testLuckyCambiaSuerteYTamano() {
        SimboloLucky simbolo = new SimboloLucky("green");
        assertFalse(simbolo.tieneSuerte());
        assertEquals(20, simbolo.obtenerTamano());
        simbolo.seleccionado();
        assertTrue(simbolo.tieneSuerte());
        assertEquals(28, simbolo.obtenerTamano());
        assertTrue(simbolo.estaVisible());
        assertEquals("lucky", simbolo.obtenerTipo());
    }

    /**
     * Comprueba que un simbolo Lucky funciona dentro de la maquina.
     */
    @Test
    public void testLuckyEnLaMaquina() {
        SlotMachine maquina = new SlotMachine();
        maquina.addSymbol("lucky", 2, "orange");
        maquina.addWheel(1);
        maquina.spin(1, 1);
        assertEquals("orange", maquina.configuration()[0]);
        assertEquals(28, maquina.tamanoSimbolo(1));
    }

    /**
     * Consultar el simbolo de una rueda que no existe no deberia funcionar.
     */
    @Test
    public void testConsultasConRuedaInvalida() {
        SlotMachine maquina = new SlotMachine();
        assertEquals(-1, maquina.tamanoSimbolo(1));
        assertFalse(maquina.simboloVisible(1));
    }
}
