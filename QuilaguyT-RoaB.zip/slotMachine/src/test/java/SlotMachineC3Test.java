import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas del Ciclo 3 de SlotMachine: maquina con n ruedas y n simbolos
 * (requisito 13) y los metodos que usa la testing tool.
 */
public class SlotMachineC3Test {

    /**
     * SlotMachine(n) crea n ruedas y n simbolos de colores diferentes.
     */
    @Test
    public void accordingJqShouldCreateMachineWithNWheelsAndSymbols() {
        SlotMachine maquina = new SlotMachine(5);
        assertEquals(5, maquina.configuration().length);
        assertEquals(5, maquina.symbols().length);
        assertEquals(5, new java.util.HashSet<>(java.util.Arrays.asList(maquina.symbols())).size());
        assertTrue(maquina.ok());
    }

    /**
     * Con n invalido la maquina se crea con una sola rueda.
     */
    @Test
    public void accordingJqShouldNotCreateMachineWithZeroWheels() {
        SlotMachine maquina = new SlotMachine(0);
        assertEquals(1, maquina.configuration().length);
    }

    /**
     * Con mas de diez ruedas tambien se generan simbolos diferentes.
     */
    @Test
    public void accordingJqShouldCreateBigMachine() {
        SlotMachine maquina = new SlotMachine(12);
        assertEquals(12, new java.util.HashSet<>(java.util.Arrays.asList(maquina.symbols())).size());
    }

    /**
     * distinctSymbols cuenta los simbolos que se ven en las ruedas,
     * no los del catalogo.
     */
    @Test
    public void accordingJqShouldCountDistinctSymbolsOnWheels() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel(1);
        maquina.addWheel(2);
        maquina.addWheel(3);
        maquina.spin(new String[] {"red", "red", "blue"});
        assertEquals(2, maquina.distinctSymbols());
        maquina.spin(new String[] {"green", "green", "green"});
        assertEquals(1, maquina.distinctSymbols());
        assertTrue(maquina.isJackpot());
    }

    /**
     * spin(wheel, steps) avanza en el orden del catalogo y da la vuelta.
     */
    @Test
    public void accordingJqShouldSpinCircularly() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel(1);
        maquina.spin(1, 3);
        assertEquals("red", maquina.configuration()[0]);
        maquina.spin(1, 4);
        assertEquals("blue", maquina.configuration()[0]);
        assertTrue(maquina.ok());
    }

    /**
     * spin(wheel, steps) no deberia funcionar sobre una posicion invalida.
     */
    @Test
    public void accordingJqShouldNotSpinStepsInvalidWheel() {
        SlotMachine maquina = new SlotMachine(3);
        maquina.spin(0, 1);
        assertFalse(maquina.ok());
        maquina.spin(4, 1);
        assertFalse(maquina.ok());
    }

    /**
     * spin con configuracion de tamaño diferente o nula no deberia funcionar.
     */
    @Test
    public void accordingJqShouldNotSetConfigurationOfWrongSize() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel(1);
        maquina.spin(new String[] {"red", "blue"});
        assertFalse(maquina.ok());
        maquina.spin((String[]) null);
        assertFalse(maquina.ok());
    }

    /**
     * Una configuracion no puede cambiar una rueda fijada.
     */
    @Test
    public void accordingJqShouldNotChangeLockedWheelWithConfiguration() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel(1);
        maquina.addWheel(2);
        maquina.lock(1);
        maquina.spin(new String[] {"blue", "blue"});
        assertFalse(maquina.ok());
        assertEquals("red", maquina.configuration()[0]);
        maquina.spin(new String[] {"red", "blue"});
        assertTrue(maquina.ok());
    }

    /**
     * No se puede girar paso a paso si la rueda tiene un simbolo eliminado.
     */
    @Test
    public void accordingJqShouldNotSpinStepsWithDeletedSymbol() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel(1);
        maquina.delSymbol("red");
        maquina.spin(1, 1);
        assertFalse(maquina.ok());
    }
}
