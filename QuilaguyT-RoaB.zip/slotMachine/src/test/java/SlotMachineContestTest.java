
import static org.junit.Assert.*;
import org.junit.Test;

public class SlotMachineContestTest {

    /**
     * Verifica que la solucion para una maquina de tres ruedas
     * genere una secuencia valida de acciones.
     */
    @Test
    public void shouldSolveThreeWheels() {
        SlotMachineContest concurso = new SlotMachineContest();

        int[][] acciones = concurso.solve(3);

        assertNotNull(acciones);
        assertTrue(acciones.length > 0);
        assertTrue(acciones.length <= 10000);

        for (int i = 0; i < acciones.length; i++) {
            assertEquals(2, acciones[i].length);

            assertTrue(
                acciones[i][0] >= 1 &&
                acciones[i][0] <= 3
            );

            assertTrue(acciones[i][1] != 0);
        }
    }

    /**
     * Verifica que la simulacion de una maquina de tres ruedas
     * pueda ejecutarse correctamente.
     */
    @Test
    public void shouldSimulateThreeWheels() {
        SlotMachineContest concurso = new SlotMachineContest();

        concurso.simulate(3);
    }
    
    /**
     * Verifica que la solucion para una maquina de cuatro ruedas
     * genere una secuencia valida de acciones.
     */
    @Test
    public void shouldSolveFourWheels() {
        SlotMachineContest concurso = new SlotMachineContest();
    
        int[][] acciones = concurso.solve(4);
    
        assertNotNull(acciones);
        assertTrue(acciones.length > 0);
        assertTrue(acciones.length <= 10000);
    }
    
    /**
     * Verifica que la simulacion de una maquina de cuatro ruedas
     * pueda ejecutarse correctamente.
     */
    @Test
    public void shouldSimulateFourWheels() {
        SlotMachineContest concurso = new SlotMachineContest();
    
        concurso.simulate(4);
    }

    /**
     * Verifica que la solucion deje la maquina en jackpot (todas las ruedas
     * con el mismo simbolo) para diferentes tamaños.
     */
    @Test
    public void shouldReachJackpot() {
        SlotMachineContest concurso = new SlotMachineContest();
        for (int n = 2; n <= 10; n++) {
            SlotMachine maquina = new SlotMachine(n);
            concurso.solve(maquina, n);
            assertTrue("n = " + n, maquina.isJackpot());
            assertEquals(1, maquina.distinctSymbols());
        }
    }

    /**
     * Verifica que la solucion funcione siempre, repitiendo muchas
     * maquinas aleatorias.
     */
    @Test
    public void shouldAlwaysReachJackpotWithRandomMachines() {
        SlotMachineContest concurso = new SlotMachineContest();
        for (int i = 0; i < 200; i++) {
            SlotMachine maquina = new SlotMachine(6);
            concurso.solve(maquina, 6);
            assertTrue(maquina.isJackpot());
        }
    }

    /**
     * Verifica que solve solo use giros con pasos positivos.
     */
    @Test
    public void shouldOnlyUsePositiveSteps() {
        int[][] acciones = new SlotMachineContest().solve(7);
        for (int[] accion : acciones) {
            assertTrue(accion[1] > 0);
            assertTrue(accion[0] >= 1 && accion[0] <= 7);
        }
    }

    /**
     * Con una sola rueda no hay nada que hacer.
     */
    @Test
    public void shouldNotDoAnythingWithOneWheel() {
        assertEquals(0, new SlotMachineContest().solve(1).length);
    }
}
