import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas del Ciclo 1 de SlotMachine (requisitos 1 a 8).
 *
 * Todas las pruebas se realizan con la maquina invisible.
 */
public class SlotMachineC1Test {

    /**
     * Una maquina nueva no tiene ruedas y trae tres simbolos.
     */
    @Test
    public void accordingJqShouldCreateEmptyMachine() {
        SlotMachine maquina = new SlotMachine();
        assertEquals(0, maquina.configuration().length);
        assertArrayEquals(new String[] {"red", "blue", "green"}, maquina.symbols());
        assertTrue(maquina.ok());
    }

    /**
     * Agregar ruedas respeta la posicion y ajusta posiciones fuera de rango.
     */
    @Test
    public void accordingJqShouldAddWheelsAdjustingPosition() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel(1);
        maquina.addWheel(99);
        maquina.addWheel(-5);
        assertEquals(3, maquina.configuration().length);
        assertTrue(maquina.ok());
    }

    /**
     * No deberia agregar una rueda de un tipo que no existe.
     */
    @Test
    public void accordingJqShouldNotAddInvalidWheelType() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel("square", 1);
        assertEquals(0, maquina.configuration().length);
        assertFalse(maquina.ok());
    }

    /**
     * Eliminar una rueda la quita de la configuracion.
     */
    @Test
    public void accordingJqShouldDeleteWheel() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel(1);
        maquina.addWheel(2);
        maquina.placeSymbol(2, "blue");
        maquina.delWheel(1);
        assertArrayEquals(new String[] {"blue"}, maquina.configuration());
        assertTrue(maquina.ok());
    }

    /**
     * No deberia eliminar ruedas si no hay o si la posicion no existe.
     */
    @Test
    public void accordingJqShouldNotDeleteInvalidWheel() {
        SlotMachine maquina = new SlotMachine();
        maquina.delWheel(1);
        assertFalse(maquina.ok());
        maquina.addWheel(1);
        maquina.delWheel(5);
        assertFalse(maquina.ok());
        assertEquals(1, maquina.configuration().length);
    }

    /**
     * Agregar y eliminar simbolos modifica el catalogo.
     */
    @Test
    public void accordingJqShouldAddAndDeleteSymbols() {
        SlotMachine maquina = new SlotMachine();
        maquina.addSymbol(1, "yellow");
        assertEquals("yellow", maquina.symbols()[0]);
        assertEquals(4, maquina.symbols().length);
        maquina.delSymbol("red");
        assertEquals(3, maquina.symbols().length);
        assertTrue(maquina.ok());
    }

    /**
     * No deberia eliminar un simbolo que no existe ni agregar un tipo invalido.
     */
    @Test
    public void accordingJqShouldNotManageInvalidSymbols() {
        SlotMachine maquina = new SlotMachine();
        maquina.delSymbol("purple");
        assertFalse(maquina.ok());
        maquina.addSymbol("weird", 1, "purple");
        assertFalse(maquina.ok());
        assertEquals(3, maquina.symbols().length);
    }

    /**
     * Girar todas las ruedas deja simbolos validos del catalogo.
     */
    @Test
    public void accordingJqShouldSpinAllWheels() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel(1);
        maquina.addWheel(2);
        maquina.spin();
        assertTrue(maquina.ok());
        for (String simbolo : maquina.configuration()) {
            assertTrue(java.util.Arrays.asList(maquina.symbols()).contains(simbolo));
        }
    }

    /**
     * No deberia girar si no hay ruedas o si la rueda no existe.
     */
    @Test
    public void accordingJqShouldNotSpinWithoutWheels() {
        SlotMachine maquina = new SlotMachine();
        maquina.spin();
        assertFalse(maquina.ok());
        maquina.spin(1);
        assertFalse(maquina.ok());
        maquina.addWheel(1);
        maquina.spin(3);
        assertFalse(maquina.ok());
    }

    /**
     * Hay jackpot solo si todas las ruedas (al menos dos) muestran lo mismo.
     */
    @Test
    public void accordingJqShouldDetectJackpot() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel(1);
        assertFalse(maquina.isJackpot());
        maquina.addWheel(2);
        maquina.placeSymbol(1, "green");
        maquina.placeSymbol(2, "green");
        assertTrue(maquina.isJackpot());
        maquina.placeSymbol(2, "red");
        assertFalse(maquina.isJackpot());
    }

    /**
     * No deberia colocar un simbolo que no esta en el catalogo.
     */
    @Test
    public void accordingJqShouldNotPlaceUnknownSymbol() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel(1);
        maquina.placeSymbol(1, "purple");
        assertFalse(maquina.ok());
        maquina.placeSymbol(4, "red");
        assertFalse(maquina.ok());
        assertEquals("red", maquina.configuration()[0]);
    }

    /**
     * Despues de hacerla invisible la maquina sigue funcionando.
     */
    @Test
    public void accordingJqShouldWorkInvisible() {
        SlotMachine maquina = new SlotMachine();
        maquina.makeInvisible();
        maquina.addWheel(1);
        maquina.spin(1);
        assertTrue(maquina.ok());
    }
}
