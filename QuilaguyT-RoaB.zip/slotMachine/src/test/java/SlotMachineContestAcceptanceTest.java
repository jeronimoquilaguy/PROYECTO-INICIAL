import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas de aceptacion del problema de la maraton.
 */
public class SlotMachineContestAcceptanceTest {

    /**
     * Como jurado, quiero que el solucionador deje una maquina de tres
     * ruedas con todas las ruedas mostrando el mismo simbolo.
     */
    @Test
    public void acceptanceTestThreeWheels() {
        SlotMachine maquina = new SlotMachine(3);
        int[][] acciones = new SlotMachineContest().solve(maquina, 3);
        assertTrue(acciones.length > 0);
        assertTrue(acciones.length <= 10000);
        assertTrue(maquina.isJackpot());
    }

    /**
     * Como jurado, quiero que el solucionador deje una maquina de cinco
     * ruedas en jackpot y sin superar el limite de acciones.
     */
    @Test
    public void acceptanceTestFiveWheels() {
        SlotMachine maquina = new SlotMachine(5);
        int[][] acciones = new SlotMachineContest().solve(maquina, 5);
        assertTrue(acciones.length <= 10000);
        assertTrue(maquina.isJackpot());
    }

    /**
     * Como usuario, quiero ver la simulacion de la solucion con la maquina
     * visible (se abre el lienzo y se ven los giros paso a paso).
     */
    @Test
    public void acceptanceTestSimulateFourWheels() {
        new SlotMachineContest().simulate(4);
    }
}
