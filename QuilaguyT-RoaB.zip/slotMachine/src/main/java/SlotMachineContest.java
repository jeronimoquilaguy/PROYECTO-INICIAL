import java.util.ArrayList;
import java.util.List;

/**
 * Resuelve el problema I de la maraton ICPC 2025 (Slot Machine).
 *
 * <p>La maquina se usa solo como testing tool: unicamente se llaman
 * {@code SlotMachine(n)}, {@code spin(wheel, steps)} y {@code distinctSymbols()}.
 * Como simulador solo se usan {@code makeVisible()} y {@code makeInvisible()}.</p>
 *
 * <p>Idea de la solucion: se alinean las ruedas una por una con la rueda 1.
 * Para alinear la rueda k se recorren sus n posiciones; en las posiciones donde
 * su simbolo ya aparece en otra rueda, la cantidad de simbolos distintos es minima.
 * Esas posiciones son las candidatas. Para saber cual candidata corresponde al
 * simbolo del grupo ya alineado (ruedas 1..k-1), se gira todo el grupo un paso
 * y se vuelve a recorrer la rueda k: solo la candidata correcta se "mueve" junto
 * con el grupo. Se repite hasta que queda una sola candidata.</p>
 *
 * Jeronimo Quilaguy - Juan Roa
 * Version 5
 */
public class SlotMachineContest {

    /**
     * Resuelve el problema con la maquina invisible.
     *
     * @param n numero de ruedas (y de simbolos) de la maquina
     * @return secuencia de acciones; cada accion es {rueda, pasos}
     */
    public int[][] solve(int n) {
        SlotMachine maquina = new SlotMachine(n);
        maquina.makeInvisible();
        return resolver(maquina, n);
    }

    /**
     * Resuelve una maquina ya creada (por ejemplo, desde una prueba).
     *
     * @param maquina maquina con n ruedas y n simbolos
     * @param n numero de ruedas (y de simbolos) de la maquina
     * @return secuencia de acciones; cada accion es {rueda, pasos}
     */
    public int[][] solve(SlotMachine maquina, int n) {
        return resolver(maquina, n);
    }

    /**
     * Simula visualmente la solucion del problema.
     *
     * @param n numero de ruedas (y de simbolos) de la maquina
     */
    public void simulate(int n) {
        SlotMachine maquina = new SlotMachine(n);
        maquina.makeVisible();
        resolver(maquina, n);
    }

    /**
     * Alinea todas las ruedas con la rueda 1.
     *
     * @param maquina maquina usada como testing tool
     * @param n numero de ruedas
     * @return acciones realizadas
     */
    private int[][] resolver(SlotMachine maquina, int n) {
        List<int[]> acciones = new ArrayList<>();
        for (int rueda = 2; rueda <= n; rueda++) {
            alinear(maquina, rueda, n, acciones);
        }
        return acciones.toArray(new int[0][]);
    }

    /**
     * Deja la rueda indicada con el mismo simbolo que las ruedas 1..rueda-1.
     *
     * @param maquina maquina usada como testing tool
     * @param rueda rueda que se va a alinear (2..n)
     * @param n numero de ruedas
     * @param acciones lista donde se registran las acciones
     */
    private void alinear(SlotMachine maquina, int rueda, int n, List<int[]> acciones) {
        boolean[] candidatas = escanear(maquina, rueda, n, acciones);
        int desplazamiento = 0;

        while (contar(candidatas) > 1 && desplazamiento < n - 1) {
            for (int grupo = 1; grupo < rueda; grupo++) {
                girar(maquina, grupo, 1, acciones);
            }
            desplazamiento++;

            boolean[] nuevas = escanear(maquina, rueda, n, acciones);
            for (int t = 0; t < n; t++) {
                candidatas[t] = candidatas[t] && nuevas[(t + desplazamiento) % n];
            }
        }

        int objetivo = primera(candidatas);
        girar(maquina, rueda, (objetivo + desplazamiento) % n, acciones);
    }

    /**
     * Recorre las n posiciones de una rueda (un paso a la vez) y marca las
     * posiciones donde la cantidad de simbolos distintos es minima.
     * Al terminar, la rueda queda en la misma posicion en que empezo.
     *
     * @param maquina maquina usada como testing tool
     * @param rueda rueda que se recorre
     * @param n numero de posiciones de la rueda
     * @param acciones lista donde se registran las acciones
     * @return arreglo con true en las posiciones de minimo
     */
    private boolean[] escanear(SlotMachine maquina, int rueda, int n, List<int[]> acciones) {
        int[] distintos = new int[n];
        int minimo = Integer.MAX_VALUE;
        for (int t = 0; t < n; t++) {
            distintos[t] = maquina.distinctSymbols();
            minimo = Math.min(minimo, distintos[t]);
            girar(maquina, rueda, 1, acciones);
        }

        boolean[] marcas = new boolean[n];
        for (int t = 0; t < n; t++) {
            marcas[t] = distintos[t] == minimo;
        }
        return marcas;
    }

    /**
     * Gira una rueda y registra la accion (si los pasos son mayores que cero).
     *
     * @param maquina maquina usada como testing tool
     * @param rueda rueda que se gira
     * @param pasos pasos que se gira la rueda
     * @param acciones lista donde se registran las acciones
     */
    private void girar(SlotMachine maquina, int rueda, int pasos, List<int[]> acciones) {
        if (pasos > 0) {
            maquina.spin(rueda, pasos);
            acciones.add(new int[] {rueda, pasos});
        }
    }

    /**
     * Cuenta cuantas posiciones estan marcadas.
     *
     * @param marcas arreglo de marcas
     * @return cantidad de posiciones en true
     */
    private int contar(boolean[] marcas) {
        int total = 0;
        for (boolean marca : marcas) {
            if (marca) {
                total++;
            }
        }
        return total;
    }

    /**
     * Retorna la primera posicion marcada.
     *
     * @param marcas arreglo de marcas
     * @return indice de la primera posicion en true, o 0 si no hay
     */
    private int primera(boolean[] marcas) {
        for (int t = 0; t < marcas.length; t++) {
            if (marcas[t]) {
                return t;
            }
        }
        return 0;
    }
}
