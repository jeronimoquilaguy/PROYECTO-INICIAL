# Informe de análisis dinámico y estático — Slot Machine (Ciclo 5)

**Desarrollo Orientado por Objetos — Proyecto inicial 2026-2**<br>
Jerónimo Quilaguy · Juan Roa

Herramientas: **JaCoCo 0.8.12** (cubrimiento de pruebas de unidad) y **PMD 7.7.0** con el conjunto de reglas `rulesets/java/quickstart.xml` (reglas de calidad para Java). Ambas se configuraron en el `pom.xml` del proyecto en VS Code.

| | Inicial | Final | Meta |
|---|---|---|---|
| Pruebas de unidad | 28 (todas pasan) | 63 (todas pasan) | — |
| Cubrimiento de instrucciones (JaCoCo) | **72,1 %** | **90,9 %** | > 75 % ✔ |
| Violaciones PMD de prioridad alta (1, rojo) | **6** | **0** | 0 ✔ |
| Violaciones PMD totales | 68 | 17 | — |

---

## 1. Análisis dinámico (JaCoCo)

### 1.1 Resultado inicial

Informe completo: `informes/jacoco-inicial/index.html`.

| Métrica | Cubrimiento |
|---|---|
| Instrucciones | 72,1 % |
| Ramas | 58,3 % |
| Líneas | 66,2 % |
| Métodos | 63,6 % |

Clases con menor cubrimiento: `SimboloLucky` (0 %), `Triangle` (0 %), `RuedaNormal` (50 %), `RuedaRebel` (57 %), `SimboloShy` (74 %) y `SlotMachine` (77 %). Además, al estudiar el resultado vimos lo siguiente:

- **No existían pruebas de los ciclos 1 y 3** (`SlotMachineC1Test`, `SlotMachineC3Test`). Los requisitos de crear, agregar y eliminar ruedas y símbolos, consultar, jackpot y `SlotMachine(n)` solo se probaban de forma indirecta.
- **Las pruebas del Contest no verificaban el resultado**. Solo revisaban que `solve` devolviera un arreglo de acciones, no que la máquina quedara en jackpot. Al agregar esa verificación encontramos que `solve` **no resolvía el problema**:
    - `distinctSymbols()` contaba los símbolos del **catálogo**, no los que se ven en las ruedas. En `SlotMachine(n)` siempre devolvía `n`, así que el algoritmo no recibía información.
    - El algoritmo usaba giros con pasos negativos, que `spin(wheel, steps)` rechaza (por diseño, según la prueba del ciclo 2).
- **En modo invisible la máquina dibujaba en el lienzo**. `Rueda.cambiarVisibilidad(true)` llamaba a `makeVisible()` del círculo aunque la máquina estuviera invisible, y esto incumplía el requisito "SlotMachine debe permanecer invisible en solve".

### 1.2 Decisiones tomadas

1. **Corregir `distinctSymbols()`** para que cuente los símbolos distintos que muestran las ruedas.
2. **Reescribir el algoritmo de `SlotMachineContest`**. Las ruedas se alinean una por una con la rueda 1, usando solo `spin(wheel, steps)` con pasos positivos y `distinctSymbols()`. Para alinear la rueda *k* se recorren sus *n* posiciones. Las posiciones donde la cantidad de símbolos distintos es mínima son las candidatas. Luego se gira un paso el grupo ya alineado y se vuelve a recorrer: la única candidata que "se mueve con el grupo" es la correcta. Se agregó `solve(SlotMachine, n)` para poder verificar el jackpot desde las pruebas. Se probó con 3.600 máquinas aleatorias (n = 1 a 12) y en todas se llegó al jackpot.
3. **Corregir el modo invisible**. `Rueda` guarda si está visible y solo dibuja el símbolo en ese caso. Ahora `solve` no abre el lienzo y es mucho más rápido.
4. **Agregar las pruebas faltantes**: `SlotMachineC1Test` (12 casos), `SlotMachineC3Test` (9 casos), y casos nuevos en `SlotMachineC4Test` (Rebel no intercambiable, Lefty en la primera posición, Ephemeral, Shy y Lucky dentro de la máquina). También se agregaron pruebas de jackpot en `SlotMachineContestTest`, `SlotMachineContestCTest` y la prueba de aceptación. Las pruebas se diseñaron pensando en qué debería hacer y qué no debería hacer cada método.
5. **Eliminar `Triangle`**, que no se usaba en el simulador (código muerto del paquete shapes).
6. **Mantener el resto del paquete shapes** (`Circle`, `Rectangle`) con cubrimiento cercano al 55 %. Los métodos sin cubrir (`moveUp`, `slowMoveHorizontal`, etc.) son del paquete reutilizado y el simulador no los usa. Decidimos no escribir pruebas artificiales para ellos.

### 1.3 Resultado final

Informe completo: `informes/jacoco-final/index.html`.

| Métrica | Inicial | Final |
|---|---|---|
| Instrucciones | 72,1 % | **90,9 %** |
| Ramas | 58,3 % | **83,5 %** |
| Líneas | 66,2 % | **87,2 %** |
| Métodos | 63,6 % | **85,7 %** |

| Clase | Inicial | Final |
|---|---|---|
| SlotMachine | 77,2 % | 96,2 % |
| SlotMachineContest | 89,6 % | 99,2 % |
| SimboloLucky | 0,0 % | 96,7 % |
| SimboloEphemeral | 84,0 % | 100 % |
| SimboloShy | 73,9 % | 82,6 % |
| RuedaNormal | 50,0 % | 100 % |
| RuedaRebel | 57,1 % | 71,4 % |
| Triangle | 0,0 % | (eliminada) |

**Meta cumplida: 90,9 % > 75 %.**

---

## 2. Análisis estático (PMD)

### 2.1 Resultado inicial

Informe completo: `informes/pmd-inicial.html`. Total: **68 violaciones**, de las cuales **6 son de prioridad 1 (alta, rojo)**.

| Prioridad | Regla | Cantidad | Dónde |
|---|---|---|---|
| 1 | MethodNamingConventions | 3 | `cambiarTamaño`, `obtenerTamaño`, `tamañoSimbolo` |
| 1 | FormalParameterNamingConventions | 1 | parámetro `tamaño` |
| 1 | ClassWithOnlyPrivateConstructorsShouldBeFinal | 2 | `Canvas` y su clase interna |
| 3 | LiteralsFirstInComparisons | 19 | `tipo.equals("normal")`, etc. |
| 3 | NoPackage | 15 | todas las clases |
| 3 | LooseCoupling | 11 | atributos declarados como `ArrayList` |
| 3 | ControlStatementBraces | 8 | `if` sin llaves en `Canvas` |
| 3 | FinalFieldCouldBeStatic | 2 | constantes `POSICION_INICIAL_X`, `ESPACIO` |
| 3 | Otras (EmptyCatchBlock, MissingOverride, SimplifyBooleanReturns, …) | 7 | |
| 4 | UnnecessaryFullyQualifiedName | 1 | `Canvas` |

### 2.2 Decisiones tomadas

**Prioridad alta (todas corregidas):**

1. **Nombres con "ñ"**. El estándar de Java (y la regla `[a-z][a-zA-Z0-9]*`) solo admite letras ASCII. Renombramos `cambiarTamaño` → `cambiarTamano`, `obtenerTamaño` → `obtenerTamano`, `tamañoSimbolo` → `tamanoSimbolo` y el parámetro `tamaño` → `tamano`. Los comentarios conservan la ortografía.
2. **`Canvas` y sus clases internas como `final`**. Solo tienen constructores privados, así que nadie puede heredar de ellas, y declararlas `final` lo deja explícito.

**Prioridad media (corregidas porque mejoran el diseño):**

3. `LiteralsFirstInComparisons`: `"normal".equals(tipo)` en lugar de `tipo.equals("normal")`. Así no se lanza `NullPointerException` si el tipo es nulo.
4. `LooseCoupling`: los atributos se declaran como `List` (interfaz) y se crean como `ArrayList`.
5. `FinalFieldCouldBeStatic`: las constantes pasan a `private static final`.
6. `MissingOverride` / polimorfismo: los métodos `mostrarTipo()` de las ruedas no se usaban, porque `SlotMachine` decidía el color con una cadena de `instanceof`. Movimos `mostrarTipo()` a `Rueda` y cada subclase lo sobrescribe con `@Override`. `SlotMachine` ahora solo llama `rueda.mostrarTipo()`, lo que mejora la extensibilidad: un nuevo tipo de rueda no obliga a modificar `SlotMachine`.
7. `ControlStatementBraces` / `EmptyCatchBlock` en `Canvas`: los colores se manejan con un `Map` y el `catch` vacío se reemplazó por `Thread.currentThread().interrupt()`. Al hacerlo extendimos el lienzo con más colores (naranja, cian, rosado, gris y colores generados para `colorN`). Antes esos símbolos se pintaban de negro y no se distinguían, lo que incumplía "los símbolos deben tener colores diferentes".
8. `SimplifyBooleanReturns`, `UncommentedEmptyMethodBody`: se simplificó `simboloVisible` y se documentó el método vacío de `SimboloNormal`.

**Prioridad media no corregidas (decisión justificada):**

- `NoPackage` (14): el proyecto usa el paquete por defecto, como se pidió desde el ciclo 1 (proyecto BlueJ con el paquete shapes). Mover las clases a un paquete cambiaría la estructura exigida por el curso.
- `NonThreadSafeSingleton` (1): el `Canvas` de shapes es un singleton que solo se usa desde un hilo. Se mantiene el diseño original del paquete reutilizado.
- `ForLoopCanBeForeach` (1) y `UnnecessaryFullyQualifiedName` (1, prioridad 4): están en el código original de shapes y no afectan la calidad del simulador.

### 2.3 Resultado final

Informe completo: `informes/pmd-final.html`.

| Prioridad | Inicial | Final |
|---|---|---|
| 1 (alta, rojo) | 6 | **0** |
| 3 | 61 | 16 |
| 4 | 1 | 1 |
| **Total** | **68** | **17** |

**Meta cumplida: 0 violaciones de prioridad alta.**

---

## 3. Otras mejoras realizadas durante el análisis

- **Distinción visual de tipos**. Los fondos de las ruedas usaban colores que también eran símbolos (magenta, azul, rojo, amarillo), así que un símbolo rojo en una rueda Rebel no se veía. Ahora los fondos tienen colores propios que no son símbolos (gris oscuro para normal, azul oscuro para lefty, rojo oscuro para rebel y dorado para el jackpot).
- **Lienzo de 700 px de ancho**, para que quepan máquinas de hasta 10 ruedas.
- **Símbolo Lucky (tipo propuesto)**: ahora se distingue visualmente, porque crece (tamaño 28) cuando tiene suerte.

## 4. Cómo reproducir los informes en VS Code

```
mvn clean test     # corre las 63 pruebas y genera target/site/jacoco/index.html
mvn pmd:pmd        # genera el informe de PMD (carpeta target)
mvn pmd:check      # falla si hay violaciones de prioridad alta
```

Las pruebas también se pueden correr desde el panel **Testing** de VS Code, con la opción **Run Tests with Coverage**.
