# Slot Machine — Proyecto inicial DOPO 2026-2

Simulador inspirado en el Problem I (*Slot Machine*) de la final mundial ICPC 2025.
Autores: Jerónimo Quilaguy · Juan Roa

## Estructura

```
src/main/java/   clases del simulador (SlotMachine, SlotMachineContest, Rueda*, Simbolo*, shapes)
src/test/java/   pruebas de unidad: SlotMachineC1Test, C2, C3, C4, Contest, compartidas (CC*) y de aceptación
informes/        INFORME_ANALISIS.pdf, informes de JaCoCo (inicial/final) y PMD (inicial/final)
SlotMachine.asta diseño en astah
retrospectiva.txt retrospectiva de los ciclos 1 a 5
pom.xml          configuración de Maven con JUnit 4, JaCoCo y PMD
```

## Abrir y ejecutar en VS Code

1. Instalar el **Extension Pack for Java** de Microsoft.
2. *File → Open Folder…* y abrir esta carpeta. VS Code detecta el `pom.xml` y descarga JUnit.
3. Panel **Testing** (ícono del matraz): **Run Tests** o **Run Tests with Coverage**.

## Informes con Maven

```
mvn clean test   # pruebas + informe JaCoCo en target/site/jacoco/index.html
mvn pmd:pmd      # informe PMD
mvn pmd:check    # falla si hay violaciones de prioridad alta
```
